"use strict";

function Framework() {
    var frameworkObject = {};

    function $(params) {
        return document.getElementById(params);
    }

    frameworkObject.makeFramework = function (params) {
        if (!params) {
            alert("You need to pass in params");
        }

        if (!params.contentDivId) {
            alert("You need to pass in a content div ID");
        }

        if (!params.buttonsDivId) {
            alert("You need to pass in a buttons div ID");
        }
        
        if(!params.hashMap) {
            alert("You need to pass the hashMap");
        }

        var buttonsDiv = $(params.buttonsDivId);
        var contentDiv = $(params.contentDivId);

        buttonsDiv.addEventListener("click", function (event) {
            var clickedItem = event.target.id;
            var fileName = params.hashMap["" + clickedItem + ""];
            var htmlText = ajaxCall(fileName);
            contentDiv.innerHTML = htmlText;
        });
        return;
    };

    function ajaxCall(url) {
        var xhttp = new XMLHttpRequest();
        xhttp.open("GET", url, false);
        xhttp.send();
        return xhttp.responseText;
    }

    return frameworkObject;
}