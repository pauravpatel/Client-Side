
demoApp.controller('customerInsertController', function ($scope, $http, SkService) {
    console.log("customerInsertController");

    // these booleans control which Save button the user will see in the 
    // person_insert_update.html (partial html file). 
    $scope.isUpdateMode = false;
    $scope.isInsertMode = true;

    // this will be used to label the heading on the customer_insert_update.html (partial html file).
    $scope.insertUpdate = "insertCustomer";

    // When the user first clicks insert, they will see the customer_insert_update.html partial 
    // and at that time, all the user data fields should have empty string (not undefined) 
    // and there is a second person object that holds all the field level error messages - 
    // clear all of those out too... 
    
    $scope.newCustomer = SkService.emptyCustomer();
    $scope.myErrors = SkService.emptyCustomer();

    //Create a new person (this is the Insert/Save button)
    $scope.insertSave = function () {
        console.log("creating customer");
        console.log($scope.newCustomer);

        // empty out all the field level user error messages in case of an ajax error 
        $scope.myErrors = SkService.emptyCustomer();

        var myData = JSON.stringify($scope.newCustomer);
        myData=escape(myData);
        var url = "webAPIs/customerInsert.jsp?jsonData=" + myData;

        $http.get(url).then(
                function (response) { // this function will run if http.get success
                    console.log("Customer Insert/Save ajax success");
                    console.log(response);
                    console.log("");
                    $scope.myErrors = response.data;
                    $scope.status = $scope.myErrors.errorMsg;
                    if ($scope.myErrors.errorMsg.length === 0) {
                        $scope.status = "Customer Sucessfully Inserted";
                    }
                },
                function (response) { // this function will run if http.get error
                    console.log("Customer Insert/Save ajax error");
                    console.log(response);
                    console.log("");
                    $scope.status = "Error: " + response.status + " " + response.statusText;

                } // end of error fn

        ); // closes off "then" function call

    };  // end of function insertSave

});  // end of insert controller