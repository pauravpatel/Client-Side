demoApp.controller('LogonCtrl', function($scope, $http, SkService){
    console.log("LogonCtrl");
    
    $scope.Cust_Email = "";
    $scope.Cust_Password = "";
    
    $scope.user = SkService.emptyUser();
    $scope.myErrors = SkService.emptyUser();
    
    $scope.logon = function(){
        $scope.myErrors = SkService.emptyUser();
        $scope.Cust_Email = $scope.user.Cust_Email;
        $scope.Cust_Password = $scope.user.Cust_Password;
        
        console.log("Cust_Email: " + $scope.Cust_Email + " Cust_Password: " + $scope.Cust_Password);
        
        var url = "webAPIs/logonAPI.jsp?Cust_Email=" + $scope.Cust_Email + "&Cust_Password=" + $scope.Cust_Password;
        console.log("url: " + url);
        $http.get(url).then(
                function(response){
                    console.log("Logon GET Success");
                    console.log(response);
                    console.log("");
                    $scope.myErrors = response.data;
                    $scope.status = $scope.myErrors.errorMsg;
                    if($scope.myErrors.errorMsg.length === 0){
                        $scope.status = "Logon Successful";
                    }
                },
                function(response){
                    console.log("Logon AJAX error");
                    console.log(response);
                    console.log("");
                    $scope.status = "Error: " + response.status + " " + response.statusText;
                }
        );
    };
});