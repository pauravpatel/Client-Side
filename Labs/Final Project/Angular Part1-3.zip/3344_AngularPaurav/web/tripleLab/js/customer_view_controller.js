demoApp.controller('customerViewController', function ($scope, $http, $routeParams, SkService) {
    
    console.log("customerViewController, Cust_ID: " + $routeParams.Cust_ID);
    
    $scope.Cust_ID = $routeParams.Cust_ID;

    // blank out the new customer in case the ajax get fails to populate newcustomer
    $scope.newCustomer = SkService.emptyCustomer();

    // blank out error message object
    $scope.myErrors = SkService.emptyCustomer();

    //Find the customer with entered id through separate JSON request to display (gets view)
    var url = "webAPIs/customerJson.jsp?Cust_ID=" + $routeParams.Cust_ID;
    $http.get(url).then(
            function (response) { // this function will run if http.get success
                console.log("Customer Update (get) ajax success");
                console.log(response);
                console.log("");
                $scope.newCustomer = response.data;
                $scope.errorMsg = "";
            },
            function (response) { // this function will run if http.get error
                console.log("Customer Update (get) ajax error");
                console.log(response);
                console.log("");
                $scope.errorMsg = "Error: " + response.status + " " + response.statusText;

            } // end of error fn
    ); // closes off "then" function call
});