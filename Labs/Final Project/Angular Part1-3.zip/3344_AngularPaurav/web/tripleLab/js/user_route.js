demoApp.config(function ($routeProvider) {
    $routeProvider.when('/', {
        templateUrl: 'htmlPartials/customer_list.html',
        controller: 'customerListController'
    }).when('/home', {
        templateUrl: 'htmlPartials/customer_list.html',
        controller: 'customerListController'

    }).when('/insertCustomer', {
        templateUrl: 'htmlPartials/customer_insert.html',
        controller: 'customerInsertController' 
                
    }).when('/list', {
        templateUrl: 'htmlPartials/user_list.html',
        controller: 'userListController'        
    }).when('/insert', {
        templateUrl: 'htmlPartials/user_insert.html',
        controller: 'userInsertController'                
    }).when('/insertUser', {
        templateUrl: 'htmlPartials/user_insert_update.html',
        controller: 'userInsertController'
    }).when('/show/:Customer_ID', {
        templateUrl: 'htmlPartials/user_detail.html',
        controller: 'userDetailController'
    }).when('/updateUser/:Customer_ID', {
        templateUrl: 'htmlPartials/user_insert_update.html',
        controller: 'userUpdateController'
    }).when('/deleteUser/:Customer_ID', {
        templateUrl: 'htmlPartials/user_list.html',
        controller: 'userListController'
    }).when('/showCustomer/:Cust_ID', {
        templateUrl: 'htmlPartials/customer_detail.html',
        controller: 'customerDetailController'
    }).when('/updateCustomer/:Cust_ID', {
        templateUrl: 'htmlPartials/customer_insert.html',
        controller: 'customerUpdateController'
    }).when('/deleteCustomer/:Cust_ID', {
        templateUrl: 'htmlPartials/customer_list.html',
        controller: 'customerListController'
    }).when('/customerView/:Cust_ID',{
        templateUrl: 'htmlPartials/customer_view.html',
        controller: 'customerViewController'
    }).when('/userView/:Customer_ID',{
        templateUrl: 'htmlPartials/user_view.html',
        controller: 'userViewController'
    }).
            when('/logon', {
                templateUrl: 'htmlPartials/logon.html',
                controller: 'LogonCtrl'
            }).
            when('/logoff', {
                templateUrl: 'htmlPartials/customer_list.html',
                controller: 'LogoffCtrl'

    }).otherwise({
        redirectTo: '/'
    });
    });
