
demoApp.controller('customerListController', function ($scope, $http, $routeParams) {

    function deleteCustomer(Cust_ID) {
        var url = "webAPIs/customerDelete.jsp?Cust_ID=" + Cust_ID;
        console.log("url to invoke: " + url);
        $scope.deleteMsg = "";

        $http.get(url).then(
                function (response) { // this function will run if http.get success
                    console.log("Customer Delete ajax success");
                    console.log(response);
                    console.log("");
                    $scope.deleteMsg = response.data.errorMsg;
                    if ($scope.deleteMsg.length === 0) {
                        $scope.deleteMsg = "Sucessfully deleted customer " + Cust_ID;
                    } else {
                        $scope.deleteMsg = "Delete Error: " + $scope.deleteMsg;
                    }
                },
                function (response) { // this function will run if http.get error
                    console.log("Customer Delete ajax error");
                    console.log(response);
                    console.log("");
                    $scope.deleteMsg = "Delete Error: " + response.status + " " + response.statusText;

                } // end of error fn
        ); // closes off "then" function call
    } // deleteCustomer

    function getCustomerList() {
        // the code to list all customers.
        $scope.listMsg = "";
        $http.get("webAPIs/customerListJson.jsp").then(
                function (response) { // this function will run if http.get success
                    console.log("GetCustomers ajax success");
                    console.log(response);
                    console.log("");
                    $scope.customers = response.data.personList;
                    $scope.listMsg = response.data.dbError;
                    if ($scope.listMsg.length > 0) {
                        $scope.listMsg = "List Error: " + $scope.listMsg;
                    }
                },
                function (response) { // this function will run if http.get error
                    console.log("Get Customers ajax error");
                    console.log(response);
                    console.log("");
                    $scope.listMsg = "List Error: " + response.status + " " + response.statusText;
                } // end of error fn
        ); // closes off "then" function call
    } // list

    // main code for this controller
    console.log("customerListController");
    console.log($routeParams);
    if ($routeParams.Cust_ID) {
        console.log("First I will delete customer " + $routeParams.Cust_ID);
        deleteCustomer($routeParams.Cust_ID);
    } else {
        console.log("Listing customers without deleting first.");
    }
    getCustomerList();

}); // end of def'n of the controller function 