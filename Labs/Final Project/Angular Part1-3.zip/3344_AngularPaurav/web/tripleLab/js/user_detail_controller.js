/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



demoApp.controller('userDetailController', function ($scope, $http, $routeParams) {
    console.log("userDetailController");
    console.log($routeParams);
    $scope.userID = $routeParams.Customer_ID;
    var url = "webAPIs/userJson.jsp?id=" + $routeParams.Customer_ID;

    $http.get(url).then(
            function (response) { // this function will run if http.get success
                console.log("User Detail ajax success");
                console.log(response);
                console.log("");
                $scope.user = response.data;
                $scope.errorMsg = "";
            },
            function (response) { // this function will run if http.get error
                console.log("User Detail ajax error");
                console.log(response);
                console.log("");
                $scope.errorMsg = "Error: " + response.status + " " + response.statusText;

            } // end of error fn
    ); // closes off "then" function call

});