/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


demoApp.controller('customerDetailController', function ($scope, $http, $routeParams) {
    console.log("customerDetailController");
    console.log($routeParams);
    $scope.Cust_ID = $routeParams.Cust_ID;
    var url = "webAPIs/bandJson.jsp?id=" + $routeParams.Cust_ID;

    $http.get(url).then(
            function (response) { // this function will run if http.get success
                console.log("Person Detail ajax success");
                console.log(response);
                console.log("");
                $scope.BandClub = response.data;
                $scope.errorMsg = "";
            },
            function (response) { // this function will run if http.get error
                console.log("Person Detail ajax error");
                console.log(response);
                console.log("");
                $scope.errorMsg = "Error: " + response.status + " " + response.statusText;

            } // end of error fn
    ); // closes off "then" function call

});