demoApp.controller('LogoffCtrl', function($scope, $http, $location){
   console.log("LogoffCtrl");
   
   $http.get("webAPIs/logoffAPI.jsp");
   
   $scope.status = "Successfully Logged Off";
   
//   $location.path("#/home");
});/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


