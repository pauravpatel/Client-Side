demoApp.controller('userViewController', function ($scope, $http, $routeParams, SkService) {
    
    console.log("userViewController, Customer_ID: " + $routeParams.Customer_ID);
    
    $scope.Customer_ID = $routeParams.Customer_ID;

    // blank out the new customer in case the ajax get fails to populate newcustomer
    $scope.newuser = SkService.emptyUser();

    // blank out error message object
    $scope.myErrors = SkService.emptyUser();

    //Find the customer with entered id through separate JSON request to display (gets view)
    var url = "webAPIs/userJson.jsp?Customer_ID=" + $routeParams.Customer_ID;
    $http.get(url).then(
            function (response) { // this function will run if http.get success
                console.log("Customer Update (get) ajax success");
                console.log(response);
                console.log("");
                $scope.newuser = response.data;
                $scope.errorMsg = "";
            },
            function (response) { // this function will run if http.get error
                console.log("Customer Update (get) ajax error");
                console.log(response);
                console.log("");
                $scope.errorMsg = "Error: " + response.status + " " + response.statusText;

            } // end of error fn
    ); // closes off "then" function call
});/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


