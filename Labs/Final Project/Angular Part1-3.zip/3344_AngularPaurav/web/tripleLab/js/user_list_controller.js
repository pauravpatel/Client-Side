
demoApp.controller('userListController', function ($scope, $http, $routeParams) {

    function deleteUser(Customer_ID) {
        var url = "webAPIs/userDelete.jsp?Customer_ID=" + Customer_ID;
        console.log("url to invoke: " + url);
        $scope.deleteMsg = "";

        $http.get(url).then(
                function (response) { // this function will run if http.get success
                    console.log("User Delete ajax success");
                    console.log(response);
                    console.log("");
                    $scope.deleteMsg = response.data.errorMsg;
                    if ($scope.deleteMsg.length === 0) {
                        $scope.deleteMsg = "Sucessfully deleted user " + Customer_ID;
                    } else {
                        $scope.deleteMsg = "Delete Error: " + $scope.deleteMsg;
                    }
                },
                function (response) { // this function will run if http.get error
                    console.log("User Delete ajax error");
                    console.log(response);
                    console.log("");
                    $scope.deleteMsg = "Delete Error: " + response.status + " " + response.statusText;

                } // end of error fn
        ); // closes off "then" function call
    } // deleteUser

    function getUserList() {
        // the code to list all users.
        $scope.listMsg = "";
        $http.get("webAPIs/userListJson.jsp").then(
                function (response) { // this function will run if http.get success
                    console.log("GetUsers ajax success");
                    console.log(response);
                    console.log("");
                    $scope.users = response.data.userList;
                    $scope.listMsg = response.data.dbError;
                    if ($scope.listMsg.length > 0) {
                        $scope.listMsg = "List Error: " + $scope.listMsg;
                    }
                },
                function (response) { // this function will run if http.get error
                    console.log("Get Users ajax error");
                    console.log(response);
                    console.log("");
                    $scope.listMsg = "List Error: " + response.status + " " + response.statusText;
                } // end of error fn
        ); // closes off "then" function call
    } // list

    // main code for this controller
    console.log("customerListController");
    console.log($routeParams);
    if ($routeParams.Customer_ID) {
        console.log("First I will delete user " + $routeParams.Customer_ID);
        deleteUser($routeParams.Customer_ID);
    } else {
        console.log("Listing users without deleting first.");
    }
    getUserList();

}); // end of def'n of the controller function 