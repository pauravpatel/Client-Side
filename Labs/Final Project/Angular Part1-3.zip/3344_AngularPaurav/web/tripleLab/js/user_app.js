// By listing 'ngRoute' in the array, it means we plan to use Angular routing
// functionality.
var demoApp = angular.module('demoApp', ['ngRoute']);

// I am creating a "service" (which is just really my class full of methods). In this service,
// I will put anything that needs to be used by more than one controller - to avoid copy/paste.
demoApp.factory("SkService", function () {

    //for planets
    var emptyCustomer = function () {
        return {
            Cust_ID: "",
            Cust_Email: "",
            Cust_Password: "",
            Cust_FirstName: "",
            Cust_LastName: "",
            Cust_Nickname: "",
            Cust_Member: "",
            Cust_Image: ""
            //description:""
        };
    };
    
    var emptyUser = function () {
        return {
            Customer_ID: "",
            Cust_SSN: "",
            Cust_IMG: "",
            Cust_CheckIn: "",
            Cust_CheckOut:"", 
            Cust_LastName:"",
            Cust_FirstName:""
        };
    };

    // expose methods (make them accessible)
    return {
        emptyCustomer: emptyCustomer,
        emptyUser: emptyUser
    };
});

//demoApp.factory("SkService2", function(){
//    //for scientists
//    var emptyUser = function () {
//        return {
//            Customer_ID: "",
//            Cust_SSN: "",
//            Cust_IMG: "",
//            Cust_CheckIn: "",
//            Cust_CheckOut:"", 
//            Cust_LastName:"",
//            Cust_FirstName:""
//        };
//    };
//
//    // expose methods (make them accessible)
//    return {
//        emptyUser: emptyUser
//        
//    };
//});