package model.person;

/* The purpose of this class is just to "bundle together" all the 
 * character data that the user might type in when they want to 
 * add a new Customer or edit an existing customer.  This String
 * data is "pre-validated" data, meaning they might have typed 
 * in a character string where a number was expected.
 * 
 * There are no getter or setter methods since we are not trying to
 * protect this data in any way.  We want to let the JSP page have
 * free access to put data in or take it out. */
public class StringData {

    public String Cust_ID = "";
    public String Cust_Email = "";
    public String Cust_Password = "";
    public String Cust_FirstName = "";
    public String Cust_LastName = "";
    public String Cust_Nickname = "";
    public String Cust_Member= "";
    public String Cust_Image = "";
    

    public String errorMsg = "";

    // default constructor leaves all data members with empty string.
    public StringData() {

    }

    public int getCharacterCount() {
        String s = this.Cust_ID + this.Cust_Email + this.Cust_Password + this.Cust_FirstName + 
                this.Cust_LastName + this.Cust_Nickname + this.Cust_Member+ this.Cust_Image;
        return s.length();
    }
}
