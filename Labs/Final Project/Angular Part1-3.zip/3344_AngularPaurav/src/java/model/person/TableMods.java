package model.person;

import dbUtils.*;

public class TableMods {

    /**
     * input parameters:
     *
     * inputData: an object that holds all the pre-validated fields that the
     * user wants to insert into the database, such as email_address, ...,
     * credit_limit. Remember that all fields in inputData are String type (even
 the dollar amount credit_limit) because this is PRE-VALIDATED data. dbc:
 an open DbConn database connection object.

 output parameter:

 If record is updated OK, return "" empty string. Otherwise, return a form
 level error message (e.g., if validation error, something like "please
 try again", or could be database error, or could be a programmer error.
     */
    public static model.person.StringData insert(model.person.StringData userData, DbConn dbc) {

        model.person.StringData errorMsgs = new model.person.StringData();

        System.out.println("In InsertUpdate.insert() ready to insert person with these values: " + userData.toString());

        errorMsgs = validate(userData);
        System.out.println("In InsertUpdate.insert() finished with validation");

        String formMsg = "";

        if (errorMsgs.getCharacterCount() > 0) {  // at least one field has an error, don't go any further.
            System.out.println("Validation errors: " + errorMsgs.toString());
            errorMsgs.errorMsg = "Please try again";
            return errorMsgs;
        } else { // all fields passed validation
            System.out.println("In InsertUpdate.insert() passed validation");

            // Start preparing SQL statement
            formMsg = dbc.getErr(); // will be empty string if DB connection is OK.
            if (formMsg.length() == 0) { // db connection is good

                // prepare the statement
                String sql = "INSERT INTO Customer (Cust_Email, Cust_Password, Cust_FirstName, Cust_LastName,"
                        + " Cust_Nickname, Cust_Member, Cust_Image) VALUES (?,?,?,?,?,?,?)";

                // PrepStatement is Sally's wrapper class for java.sql.PreparedStatement
                // Only difference is that Sally's class takes care of encoding null 
                // when necessary. And it also System.out.prints exception error messages.
                PrepStatement pStatement = new PrepStatement(dbc, sql);

                // Encoding string values into the prepared statement is pretty easy...
//                pStatement.setString(1, userData.Cust_ID);
                pStatement.setString(1, userData.Cust_Email);
                pStatement.setString(2, userData.Cust_Password);
                pStatement.setString(3, userData.Cust_FirstName);
                pStatement.setString(4, userData.Cust_LastName);
                pStatement.setString(5, userData.Cust_Nickname);
                pStatement.setString(6, userData.Cust_Member);
                pStatement.setString(7, userData.Cust_Image);

                //pStatement.setInt(2, ValidationUtils.integerConversion(userData.age));
                System.out.println("ready to execute insert");

                // here the INSERT is actually executed
                int numRows = pStatement.executeUpdate();

                // This will return empty string if all went well, else all error messages.
                formMsg = pStatement.getErrorMsg();
                System.out.println("Error msg from after executing the insert: " + formMsg);

                if (formMsg.length() == 0) {
                    if (numRows == 1) {
                        formMsg = ""; // This means SUCCESS. Let the JSP page decide how to tell this to the user.
                    } else {
                        // probably never get here unless you forgot your WHERE clause and did a bulk sql update.
                        formMsg = numRows + " records were inserted when exactly 1 was expected.";
                    }
                    System.out.println("Number of records affected: " + numRows);
                }
            } // Db Connection is good - double check, JSP page should not send us a bad one... 
        } // customerId is not null and not empty string.
        errorMsgs.errorMsg = formMsg;
        return errorMsgs;
    } // constructor method

    /**
     * input parameters:
     *
     * inputData: an object that holds all the pre-validated fields that the
     * user wants to update into the database. Remember that all fields in
     * inputData are String type because this is PRE-VALIDATED data. dbc: an
     * open DbConn database connection object.
     *
     * output parameter:
     *
     * If record is updated OK, return "" empty string. Otherwise, return a form
     * level error message (e.g., if validation error, something like "please
     * try again", or could be database error, or could be a programmer error
     * msg).
     */
    public static model.person.StringData update(model.person.StringData userData, DbConn dbc) {

        model.person.StringData errorMsgs = new model.person.StringData();

        System.out.println("In InsertUpdate.update() ready to update person with these values: " + userData.toString());

        if (userData.Cust_ID == null) {
            errorMsgs.errorMsg = "Programmer error: for update, person Id should not be null.";
            return errorMsgs;
        }
        if (userData.Cust_ID.length() == 0) {
            errorMsgs.errorMsg = "Programmer error: for update, person Id should not be empty string.";
            return errorMsgs;
        }

        errorMsgs = validate(userData);
        System.out.println("In InsertUpdate.update() finished with validation");

        String formMsg = "";

        if (errorMsgs.getCharacterCount() > 0) {  // at least one field has an error, don't go any further.
            System.out.println("Validation errors: " + errorMsgs.toString());
            errorMsgs.errorMsg = "Please try again";
            return errorMsgs;

        } else { // all fields passed validation
            System.out.println("In InsertUpdate.update() passed validation");

            // Start preparing SQL statement
            formMsg = dbc.getErr(); // will be empty string if DB connection is OK.
            if (formMsg.length() == 0) { // db connection is good

                // prepare the statement
                String sql = "UPDATE Customer SET Cust_Email=?, Cust_Password=?, Cust_FirstName=?,Cust_LastName=?,Cust_Nickname=?, Cust_Member=?, Cust_Image=?  WHERE Cust_ID=?";

                // PrepStatement is Sally's wrapper class for java.sql.PreparedStatement
                // Only difference is that Sally's class takes care of encoding null 
                // when necessary. And it also System.out.prints exception error messages.
                PrepStatement pStatement = new PrepStatement(dbc, sql);

                pStatement.setString(8, userData.Cust_ID);
                pStatement.setString(1, userData.Cust_Email);
                pStatement.setString(2, userData.Cust_Password);
                pStatement.setString(3, userData.Cust_FirstName);
                pStatement.setString(4, userData.Cust_LastName);
                pStatement.setString(5, userData.Cust_Nickname);
                pStatement.setString(6, userData.Cust_Member);
                pStatement.setString(7, userData.Cust_Image);

                System.out.println("ready to execute update, id is " + userData.Cust_ID);

                // here the UPDATE is actually executed
                int numRows = pStatement.executeUpdate();

                // This will return empty string if all went well, else all error messages.
                formMsg = pStatement.getErrorMsg();
                System.out.println("Error msg from after executing the update: " + formMsg);

                if (formMsg.length() == 0) {
                    if (numRows == 1) {
                        formMsg = ""; // This means SUCCESS. Let the JSP page decide how to tell this to the user.
                    } else {
                        // probably never get here unless you forgot your WHERE clause and did a bulk sql update.
                        formMsg = numRows + " records were updated when only 1 was expected.";
                    }
                    System.out.println("Number of records affected: " + numRows);
                }
            } // Db Connection is good - double check, JSP page should not send us a bad one... 
        } // customerId is not null and not empty string.
        errorMsgs.errorMsg = formMsg;
        return errorMsgs;
    } // constructor method

    private static model.person.StringData validate(model.person.StringData inputData) {

        model.person.StringData errorMsgs = new model.person.StringData();

        // Validation
        errorMsgs.Cust_ID = ValidationUtils.stringValidationMsg(inputData.Cust_ID, 1024, false);
        errorMsgs.Cust_Email = ValidationUtils.stringValidationMsg(inputData.Cust_Email, 1024, true);
        errorMsgs.Cust_Password = ValidationUtils.stringValidationMsg(inputData.Cust_Password, 45, true);
        errorMsgs.Cust_FirstName = ValidationUtils.stringValidationMsg(inputData.Cust_FirstName, 1024, true);
        errorMsgs.Cust_LastName = ValidationUtils.stringValidationMsg(inputData.Cust_LastName, 1024, true);
        errorMsgs.Cust_Nickname = ValidationUtils.stringValidationMsg(inputData.Cust_Nickname, 1024, false);
        errorMsgs.Cust_Member = ValidationUtils.stringValidationMsg(inputData.Cust_Member, 1024, true);
        errorMsgs.Cust_Image = ValidationUtils.stringValidationMsg(inputData.Cust_Image, 1024, true);

        return errorMsgs;
    }
    
    
    
    public static String deleteById(String id, DbConn dbc) {

        if (id == null) {
            return "Programmer error: for delete, UserID should not be null.";
        }
        if (id.length() == 0) {
            return "Programmer error: for delete, UserID should not be empty string.";
        }

        String formMsg = dbc.getErr(); // will be empty string if DB connection is OK.

        if (formMsg.length() == 0) { // db connection is good

            // prepare the statement 
            String sql = "DELETE FROM Customer WHERE Cust_ID=?";

            // PrepStatement is Sally's wrapper class for java.sql.PreparedStatement
            // Only difference is that Sally's class takes care of encoding null 
            // when necessary. And it also System.out.prints exception error messages.
            PrepStatement pStatement = new PrepStatement(dbc, sql);

            // Encoding string values into the prepared statement is pretty easy...
            pStatement.setString(1, id);

            // here the DELETE is actually executed (executeUpdate is used for any SQL other than SELECT, 
            // so that includes insert, update, and delete)
            int numRows = pStatement.executeUpdate();

            // This will return empty string if all went well, else all error messages.
            formMsg = pStatement.getErrorMsg();
            if (formMsg.length() == 0) {
                if (numRows == 1) {
                    formMsg = ""; // This means SUCCESS. Let the JSP page decide how to tell this to the user.
                } else {
                    // probably never get here unless you forgot your WHERE clause and did a bulk sql update.
                    formMsg = numRows + " records were deleted (expected to delete 1).";
                }
            }
        } // Db Connection is good - double check, JSP page should not send us a bad one... 
        return formMsg;
    }
    
    
    
} // Class