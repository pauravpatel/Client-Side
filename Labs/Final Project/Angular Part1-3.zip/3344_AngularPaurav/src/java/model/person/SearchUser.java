/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.person;

import dbUtils.*;
import java.sql.*;

/**
 *
 * @author Administrator
 */
public class SearchUser {
    
public static StringData logon(String Cust_Email, String Cust_Password, DbConn dbc){
        StringData userErrors = new StringData();
        
        if(Cust_Email == null || Cust_Password == null){
            userErrors.errorMsg = "Email or Password was null. They can't be null";
            return userErrors;
        }
        
        try{
            String sql = "SELECT Cust_FirstName, Cust_Email, Cust_Password FROM Customer WHERE Cust_Email=? AND Cust_Password=?";
        
            PreparedStatement pStatement = dbc.getConn().prepareStatement(sql);
            
            pStatement.setString(1, Cust_Email);
            pStatement.setString(2, Cust_Password);
            
            ResultSet results = pStatement.executeQuery();
            
            if(results.next()){
                userErrors.Cust_Email = Cust_Email;
                userErrors.Cust_FirstName = FormatUtils.formatString(results.getObject("Cust_FirstName"));
                return userErrors;
            } else {
                return null;
            }
            
        } catch (Exception e){
            userErrors.errorMsg = "Exception while logging on: " + e.getMessage();
            System.out.println("*******" + userErrors.errorMsg);
        }
        
        return userErrors;
    }
}