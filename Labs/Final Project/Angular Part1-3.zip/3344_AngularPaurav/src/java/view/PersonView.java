package view;

// classes imported from java.sql.*
import java.sql.PreparedStatement;
import java.sql.ResultSet;

// classes in my project
import dbUtils.*;
import model.person.*;

public class PersonView {

    public static StringData extractPerson(ResultSet results) {
        StringData person = new StringData();
        try {
            person.Cust_ID = FormatUtils.formatInteger(results.getObject("Cust_ID"));
            person.Cust_Email = FormatUtils.formatString(results.getObject("Cust_Email"));
            person.Cust_Password = FormatUtils.formatString(results.getObject("Cust_Password"));
            person.Cust_FirstName = FormatUtils.formatString(results.getObject("Cust_FirstName"));
            person.Cust_LastName = FormatUtils.formatString(results.getObject("Cust_LastName"));
            person.Cust_Nickname = FormatUtils.formatString(results.getObject("Cust_Nickname"));
             person.Cust_Member = FormatUtils.formatString(results.getObject("Cust_Member"));
              person.Cust_Image = FormatUtils.formatString(results.getObject("Cust_Image"));
            
            

            
            
        } catch (Exception e) {
            person.errorMsg = "Data Exception thrown in PersonView.extractPerson(): " + e.getMessage();
            System.out.println("*****" + person.errorMsg);
        }
        return person;
    }

    public static StringDataList buildPersonList(DbConn dbc) {

        StringDataList personList = new StringDataList();

        personList.dbError = dbc.getErr();
        if (personList.dbError.length() == 0) {

            String sql = "SELECT Cust_ID, Cust_Email, Cust_Password, Cust_FirstName, Cust_LastName,Cust_Nickname,Cust_Member,Cust_Image  "
                    + "FROM Customer";

            try {
                PreparedStatement stmt = dbc.getConn().prepareStatement(sql);
                ResultSet results = stmt.executeQuery();

                while (results.next()) {
                    personList.add(extractPerson(results));
                }
            } catch (Exception e) {
                personList.dbError = "SQL Excepption thrown in PersonView.BuildPersonList(): " + e.getMessage();
                System.out.println("*****" + personList.dbError);
            }
        }
        return personList;
    }

    public static StringData findPersonById(DbConn dbc, String id) {

        StringData person = new StringData();

        if (id == null) {
            person.errorMsg = "Cannot find person with null id.";
            return person;
        }

        person.errorMsg = dbc.getErr();
        if (person.errorMsg.length() == 0) {

            

             String sql = "SELECT Cust_ID, Cust_Email, Cust_Password, Cust_FirstName, Cust_LastName,Cust_Nickname,Cust_Member,Cust_Image  "
                    + "FROM Customer Where Cust_ID=?";
            try {
                PreparedStatement stmt = dbc.getConn().prepareStatement(sql);
                stmt.setString(1, id);
                ResultSet results = stmt.executeQuery();

                if (results.next()) {
                    person = extractPerson(results);
                }
            } catch (Exception e) {
                person.errorMsg = "SQL Exception thrown in PersonView.BuildPerson(): " + e.getMessage();
                System.out.println("*****" + person.errorMsg);
            }
        }
        return person;
    }

}
