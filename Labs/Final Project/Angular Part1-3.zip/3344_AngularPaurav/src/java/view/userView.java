package view;

// classes imported from java.sql.*
import java.sql.PreparedStatement;
import java.sql.ResultSet;

// classes in my project
import dbUtils.*;
import model.user.*;

public class userView {

    public static StringData extractUser(ResultSet results) {
        StringData user = new StringData();
        try {
            user.Customer_ID = FormatUtils.formatInteger(results.getObject("Customer_ID"));
            user.Cust_SSN = FormatUtils.formatString(results.getObject("Cust_SSN"));
            user.Cust_IMG = FormatUtils.formatString(results.getObject("Cust_IMG"));
            user.Cust_CheckIn = FormatUtils.formatDate(results.getObject("Cust_CheckIn"));
            user.Cust_CheckOut = FormatUtils.formatDate(results.getObject("Cust_CheckOut"));
            user.Cust_LastName = FormatUtils.formatString(results.getObject("Cust_LastName"));
            user.Cust_FirstName = FormatUtils.formatString(results.getObject("Cust_FirstName"));
            


        } catch (Exception e) {
            user.errorMsg = "Data Exception thrown in UserView.extractUser(): " + e.getMessage();
            System.out.println("*****" + user.errorMsg);
        }
        return user;
    }

    public static StringDataList buildUserList(DbConn dbc) {

        StringDataList userList = new StringDataList();

        userList.dbError = dbc.getErr();
        if (userList.dbError.length() == 0) {

            String sql = "SELECT Customer_ID, Cust_SSN, Cust_IMG, Cust_CheckIn,Cust_CheckOut,"
                    + "Cust_LastName,Cust_FirstName "
                    + "FROM Customer_Data Where Customer_ID";

            try {
                PreparedStatement stmt = dbc.getConn().prepareStatement(sql);
                ResultSet results = stmt.executeQuery();

                while (results.next()) {
                    userList.add(extractUser(results));
                }
            } catch (Exception e) {
                userList.dbError = "SQL Excepption thrown in UserView.BuildUserList(): " + e.getMessage();
                System.out.println("*****" + userList.dbError);
            }
        }
        return userList;
    }

    public static StringData findUserById(DbConn dbc, String id) {

        StringData user = new StringData();

        if (id == null) {
            user.errorMsg = "Cannot find user with null id.";
            return user;
        }

        user.errorMsg = dbc.getErr();
        if (user.errorMsg.length() == 0) {

            
             String sql = "SELECT Customer_ID, Cust_SSN, Cust_IMG, Cust_CheckIn,Cust_CheckOut,"
                    + "Cust_LastName,Cust_FirstName "
                    + "FROM Customer_Data Where Customer_ID =?";


            try {
                PreparedStatement stmt = dbc.getConn().prepareStatement(sql);
                stmt.setString(1, id);
                ResultSet results = stmt.executeQuery();

                if (results.next()) {
                    user = extractUser(results);
                }
            } catch (Exception e) {
                user.errorMsg = "SQL Exception thrown in userView.BuildUser(): " + e.getMessage();
                System.out.println("*****" + user.errorMsg);
            }
        }
        return user;
    }

}
