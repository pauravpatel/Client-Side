package model.Customer;



public class StringData {

    // select country_id, country_name, flag_abbrev, flag_URL from country_flag
    public String Cust_ID = "";
    public String Cust_Email = "";
    public String Cust_Password="";
    public String Cust_Nickname =""; 
    public String Cust_FirstName="";
    public String Cust_LastName="";
    public String Cust_Image = "";
   // public String Cust_Member = "";
   
    public String errorMsg ="";
   
}