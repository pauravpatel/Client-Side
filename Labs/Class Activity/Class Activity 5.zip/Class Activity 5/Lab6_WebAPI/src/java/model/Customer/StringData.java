package model.Customer;



public class StringData {

    // select country_id, country_name, flag_abbrev, flag_URL from country_flag
    public String Cust_ID = "";
    public String Cust_Email = "";
   
    public String errorMsg ="";
   
}